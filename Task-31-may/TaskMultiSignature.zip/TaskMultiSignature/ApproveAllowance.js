const {
  Client,
  Hbar,
  PrivateKey,
  AccountAllowanceApproveTransaction,
} = require('@hashgraph/sdk');

require('dotenv').config({ path: '../.env' });

const myAccountId = '0.0.10569267';
const myPrivateKey = PrivateKey.fromString(
  '3030020100300706052b8104000a042204202d3fabf91a7ebb3d01e81d93c3a5a5b7c2900c8fb17ddd517f28486b1657a410'
);

const myAccountId2 = '0.0.10568976';
const myPrivateKey2 = PrivateKey.fromString(
  '302e020100300506032b657004220420dea199107c67f01d2af3f0b4af9488a5c9c974f5df59776f6bd4d203a4139468'
);
console.log(myAccountId, myAccountId2);

const client = Client.forTestnet();
client.setOperator(myAccountId, myPrivateKey);

const client2 = Client.forTestnet();
client2.setOperator(myAccountId2, myPrivateKey2);

async function approveAllowance() {
  // Create the transaction
  const transaction = new AccountAllowanceApproveTransaction()
    .approveHbarAllowance(myAccountId, myAccountId2, Hbar.from(35))
    .freezeWith(client);
  //Sign the transaction with the owner account key
  const signTx = await transaction.sign(myPrivateKey);
  //Sign the transaction with the client operator private key and submit to a Hedera network
  const txResponse = await signTx.execute(client);
  //Request the receipt of the transaction
  const receipt = await txResponse.getReceipt(client);
  //Get the transaction consensus status
  const transactionStatus = receipt.status;
  console.log(
    'The transaction consensus status is ' +
      transactionStatus.toString()
  );
}

approveAllowance();
